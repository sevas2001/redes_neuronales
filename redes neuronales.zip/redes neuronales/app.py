import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from dash import Dash, html, dcc, Input, Output, State
import base64
import plotly.express as px
import plotly.graph_objects as go

# ============================================================
# 0. CARGAR LOGO UAX
# ============================================================
with open("uax.png", "rb") as f:
    uax_base64 = base64.b64encode(f.read()).decode("ascii")

# ============================================================
# 1. CARGAR MODELO, PREPROCESADO Y PACIENTES REALES
# ============================================================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

scaler = joblib.load("datos_app/scaler.pkl")
num_medians = joblib.load("datos_app/num_medians.pkl")
original_num_cols = joblib.load("datos_app/original_num_cols.pkl")
missing_flag_cols = joblib.load("datos_app/missing_flag_cols.pkl")
cat_cols = joblib.load("datos_app/cat_cols.pkl")
label_encoders = joblib.load("datos_app/label_encoders.pkl")

# rangos aproximados para labels de filtros numéricos
NUM_RANGES = {
    col: (lo, hi)
    for col, lo, hi in zip(
        original_num_cols,
        scaler.data_min_,
        scaler.data_max_,
    )
}

# --- cargar pacientes reales ---
drop_cols = [
    'estadio_ajcc','ecog','mut_kras','receptor_hormonal','programa_prevencion',
    'respuesta_previa','mut_braf','biopsia_tipo','metastasis','cuidados_paliativos',
    't_invasivo','sexo','n_linfatico','aseguradora','tmb_alto','comite_tumores',
    'psicooncologia','mut_egfr','mut_pi3k'
]

df_all = pd.read_csv("datos/onc_train_full_with_target.csv")
df_all = df_all.drop(columns=drop_cols)
assert "vive" in df_all.columns, "La columna 'vive' debe estar en datos/onc_train_full_with_target.csv"

# ============================================================
# 1.1. DEFINIR MODELO (MISMA ARQUITECTURA QUE EN TRAIN)
# ============================================================
hidden_sizes = [512, 256, 125, 64, 64, 64, 32, 16]

class CancerMLP(nn.Module):
    def __init__(self, n_features: int, hidden_sizes):
        super().__init__()
        self.hidden_layers = nn.ModuleList()
        in_features = n_features
        for h in hidden_sizes:
            self.hidden_layers.append(nn.Linear(in_features, h))
            in_features = h
        self.out = nn.Linear(in_features, 1)

    def forward(self, x):
        for i, layer in enumerate(self.hidden_layers):
            x = layer(x)
            if i == 0:
                x = torch.atan(x)
            else:
                x = torch.relu(x)
        x = self.out(x)
        x = torch.sigmoid(x)
        return x

n_features = len(original_num_cols) + len(missing_flag_cols) + len(cat_cols)
model = CancerMLP(n_features, hidden_sizes).to(device)
state_dict = torch.load("best_model_struct.pt", map_location=device)
model.load_state_dict(state_dict)
model.eval()

# ============================================================
# 1.2. PREDICCIONES PARA TODO EL DATASET (para histograma y calibración)
# ============================================================
def predict_batch(df: pd.DataFrame) -> np.ndarray:
    df_num = df[original_num_cols].copy()

    for col in original_num_cols:
        df_num[col + "_missing"] = df_num[col].isna().astype(int)
        df_num[col] = df_num[col].fillna(num_medians[col])

    num_scaled_vals = scaler.transform(df_num[original_num_cols].values.astype("float32"))
    df_num_scaled = pd.DataFrame(num_scaled_vals, columns=original_num_cols, index=df.index)

    for col in missing_flag_cols:
        df_num_scaled[col] = df_num[col].values

    df_cat = df[cat_cols].copy().fillna("MISSING")
    for col in cat_cols:
        enc = label_encoders[col]
        known = set(enc.classes_)
        df_cat[col] = (
            df_cat[col]
            .astype(str)
            .where(df_cat[col].astype(str).isin(known), other="MISSING")
        )
        df_cat[col] = enc.transform(df_cat[col].astype(str))

    X_all = np.hstack([
        df_num_scaled.values.astype("float32"),
        df_cat.values.astype("float32")
    ])

    x_tensor = torch.from_numpy(X_all).float().to(device)
    with torch.no_grad():
        probs = model(x_tensor).squeeze(1).cpu().numpy()
    return probs

# calcular probas para todo el dataset
df_all["prob_model"] = predict_batch(df_all)

# ============================================================
# 1.3. CURVA DE CALIBRACIÓN GLOBAL
# ============================================================
def compute_calibration(df, n_bins=10):
    probs = df["prob_model"].values
    y = df["vive"].values
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    bin_ids = np.digitize(probs, bins) - 1
    bin_centers = []
    mean_pred = []
    frac_pos = []
    for b in range(n_bins):
        mask = bin_ids == b
        if mask.sum() == 0:
            continue
        p_bin = probs[mask]
        y_bin = y[mask]
        bin_centers.append((bins[b] + bins[b+1]) / 2.0)
        mean_pred.append(p_bin.mean())
        frac_pos.append(y_bin.mean())
    return np.array(bin_centers), np.array(mean_pred), np.array(frac_pos)

bin_centers, mean_pred, frac_pos = compute_calibration(df_all)

fig_calib = go.Figure()
fig_calib.add_trace(go.Scatter(
    x=[0, 1], y=[0, 1],
    mode="lines",
    name="Calibración perfecta",
    line=dict(dash="dash")
))
fig_calib.add_trace(go.Scatter(
    x=mean_pred,
    y=frac_pos,
    mode="lines+markers",
    name="Modelo",
))
fig_calib.update_layout(
    margin=dict(l=60, r=20, t=40, b=40),
    xaxis_title="Probabilidad predicha media",
    yaxis_title="Frecuencia real de supervivencia",
    title="Curva de calibración global",
    height=350,
)

# ============================================================
# 2. VARIABLES PARA FILTRAR PACIENTES
# ============================================================
FILTER_NUM = ["edad", "hemoglobina"]
FILTER_CAT = ["tipo_tumor", "tratamiento_actual", "hospital_tipo"]

filter_cat_options = {
    col: sorted(df_all[col].dropna().astype(str).unique().tolist())
    for col in FILTER_CAT
}

def numeric_label(col):
    if col in NUM_RANGES:
        lo, hi = NUM_RANGES[col]
        return f"{col} (≈ {lo:.1f} – {hi:.1f})"
    return col

# ============================================================
# 3. FUNCIÓN: PREDICCIÓN PARA UNA FILA (ya tenemos prob_model, pero por coherencia)
# ============================================================
def predict_from_row(row: pd.Series) -> float:
    # aquí podríamos usar directamente row["prob_model"], pero mantenemos la función por si quieres comparar
    return float(row["prob_model"])

# ============================================================
# 4. TEXTO, BARRA DE RIESGO Y COMENTARIO
# ============================================================
def texto_recomendacion(prob):
    if prob < 0.2:
        return "Riesgo muy alto de fallecimiento. Probabilidad de supervivencia baja. Priorizar valoración en comité y considerar estrategias terapéuticas intensivas."
    elif prob < 0.5:
        return "Riesgo elevado. Paciente con múltiples factores desfavorables. Recomendable revisión detallada del caso y seguimiento estrecho."
    elif prob < 0.8:
        return "Riesgo intermedio. Combina factores de buen y mal pronóstico. Valorar individualmente según contexto clínico."
    else:
        return "Riesgo bajo. El modelo estima alta probabilidad de supervivencia. Mantener seguimiento estándar y reevaluar ante cambios clínicos."

def categoria_riesgo(prob):
    prob_die = 1.0 - prob
    if prob_die < 0.2:
        return "🟢 Riesgo de fallecimiento: MUY BAJO", "#198754"
    elif prob_die < 0.5:
        return "🔵 Riesgo de fallecimiento: BAJO-MODERADO", "#0d6efd"
    elif prob_die < 0.8:
        return "🟠 Riesgo de fallecimiento: MODERADO-ALTO", "#fd7e14"
    else:
        return "🔴 Riesgo de fallecimiento: MUY ALTO", "#dc3545"

def barra_riesgo(prob):
    prob_live = prob
    prob_die = 1.0 - prob
    titulo, color = categoria_riesgo(prob)

    width = f"{prob_die * 100:.1f}%"

    return html.Div(
        children=[
            html.Div(
                titulo,
                style={
                    "fontSize": "15px",
                    "fontWeight": "600",
                    "marginBottom": "6px",
                    "color": "#343a40",
                },
            ),
            html.Div(
                style={
                    "width": "100%",
                    "height": "18px",
                    "backgroundColor": "#e9ecef",
                    "borderRadius": "999px",
                    "overflow": "hidden",
                },
                children=[
                    html.Div(
                        style={
                            "width": width,
                            "height": "100%",
                            "backgroundColor": color,
                            "transition": "width 0.4s ease",
                        }
                    )
                ],
            ),
            html.Div(
                f"Prob. supervivencia: {prob_live*100:.1f}%   |   Prob. fallecimiento: {prob_die*100:.1f}%",
                style={
                    "fontSize": "13px",
                    "color": "#6c757d",
                    "marginTop": "6px",
                },
            ),
        ]
    )

def comentario_caso(prob, vive_real):
    """
    Pequeño texto tipo 'discusión' según coincide o no el modelo con la realidad.
    """
    if prob >= 0.7 and vive_real == 1:
        return "En este caso el modelo estima alta probabilidad de supervivencia y el paciente efectivamente sobrevivió, lo que sugiere buena coherencia entre predicción y desenlace."
    elif prob <= 0.3 and vive_real == 0:
        return "El modelo identifica correctamente un paciente de alto riesgo de fallecimiento, con buena concordancia entre la estimación y el desenlace observado."
    elif prob >= 0.7 and vive_real == 0:
        return "Aquí el modelo infraestima el riesgo: predice una alta probabilidad de supervivencia, pero el paciente falleció. Este tipo de casos puede señalar factores clínicos no capturados por las variables disponibles."
    elif prob <= 0.3 and vive_real == 1:
        return "En este paciente el modelo sobreestima el riesgo de fallecimiento, ya que finalmente sobrevivió. Resulta útil para explorar qué características pueden estar penalizando en exceso la predicción."
    else:
        return "La estimación del modelo y el desenlace real son intermedios, sin discrepancias extremas. Este tipo de casos ayuda a evaluar el comportamiento del modelo en zonas de riesgo moderado."

# ============================================================
# 5. GRÁFICOS DINÁMICOS: SIMILARES Y PERFIL CLÍNICO
# ============================================================
NUM_PERFIL = ["edad", "hemoglobina", "glucosa", "albumina"]
NUM_PERFIL = [c for c in NUM_PERFIL if c in df_all.columns]

# precomputar rangos para normalizar
perfil_min = {c: df_all[c].min() for c in NUM_PERFIL}
perfil_max = {c: df_all[c].max() for c in NUM_PERFIL}

def grafico_perfil(row: pd.Series):
    if not NUM_PERFIL:
        return go.Figure()

    vals = []
    norm_vals = []
    labels = []
    for col in NUM_PERFIL:
        v = row[col]
        lo, hi = perfil_min[col], perfil_max[col]
        if hi > lo:
            nv = (v - lo) / (hi - lo)
        else:
            nv = 0.5
        vals.append(v)
        norm_vals.append(nv)
        labels.append(col)

    df_plot = pd.DataFrame({
        "variable": labels,
        "valor_norm": norm_vals,
        "valor_real": vals,
    })

    fig = go.Figure(
        data=go.Bar(
            x=df_plot["valor_norm"],
            y=df_plot["variable"],
            orientation="h",
            text=[f"{v:.2f}" for v in df_plot["valor_real"]],
            textposition="auto",
        )
    )
    fig.update_layout(
        xaxis=dict(range=[0, 1], title="Posición en el rango de la cohorte"),
        yaxis=dict(title="Variable"),
        margin=dict(l=80, r=20, t=40, b=40),
        height=300,
        title="Perfil clínico numérico del paciente (normalizado)",
    )
    return fig

def grafico_similares(row: pd.Series):
    # intentar filtrar por mismo tipo_tumor y tratamiento_actual
    mask = (
        (df_all["tipo_tumor"].astype(str) == str(row["tipo_tumor"])) &
        (df_all["tratamiento_actual"].astype(str) == str(row["tratamiento_actual"]))
    )
    dff = df_all[mask]

    # si hay muy pocos, ampliar a solo tipo_tumor
    if len(dff) < 10:
        dff = df_all[df_all["tipo_tumor"].astype(str) == str(row["tipo_tumor"])]

    if len(dff) == 0:
        return go.Figure()

    fig = px.histogram(
        dff,
        x="prob_model",
        nbins=20,
        labels={"prob_model": "Probabilidad de supervivencia (modelo)"},
    )
    fig.add_vline(
        x=float(row["prob_model"]),
        line_color="red",
        line_width=2,
        annotation_text="Paciente seleccionado",
        annotation_position="top right",
    )
    fig.update_layout(
        margin=dict(l=60, r=20, t=40, b=40),
        height=300,
        title="Distribución de probabilidad en pacientes similares",
    )
    return fig

# ============================================================
# 6. INFO DEL DATASET
# ============================================================
n_pacientes = len(df_all)
n_num = len(original_num_cols)
n_cat = len(cat_cols)
prop_vive = df_all["vive"].mean()

dataset_info_text = (
    f"Nº de pacientes: {n_pacientes} · "
    f"Variables numéricas: {n_num} · "
    f"Variables categóricas: {n_cat} · "
    f"Proporción que sobrevive (vive=1): {prop_vive*100:.1f}%"
)

# ============================================================
# 7. APP DASH
# ============================================================
app = Dash(__name__)

app.layout = html.Div(
    style={
        "minHeight": "100vh",
        "backgroundColor": "#f4f6f9",
        "fontFamily": "Segoe UI, Arial, sans-serif",
        "padding": "20px",
    },
    children=[
        html.Div(
            style={
                "maxWidth": "1150px",
                "margin": "0 auto",
                "backgroundColor": "white",
                "borderRadius": "12px",
                "boxShadow": "0 4px 16px rgba(0,0,0,0.08)",
                "padding": "25px 30px 30px 30px",
            },
            children=[
                # HEADER
                html.Div([
                    html.Div(
                        style={
                            "display": "flex",
                            "alignItems": "center",
                            "justifyContent": "space-between",
                            "marginBottom": "10px",
                        },
                        children=[
                            html.Img(
                                src=f"data:image/png;base64,{uax_base64}",
                                style={"height": "100px", "marginRight": "30px"},
                            ),
                            html.Div(
                                children=[
                                    html.H1(
                                        "Asistente de riesgo oncológico (pacientes reales)",
                                        style={
                                            "color": "#0b5ed7",
                                            "marginBottom": "3px",
                                            "fontWeight": "600",
                                            "fontSize": "24px",
                                        },
                                    ),
                                    html.P(
                                        "Selección de pacientes del dataset real · Probabilidad del modelo vs resultado observado",
                                        style={
                                            "color": "#6c757d",
                                            "marginTop": "0",
                                            "fontSize": "13px",
                                        },
                                    ),
                                ]
                            ),
                        ],
                    ),
                    html.Hr(),
                ]),

                # FILTROS
                html.Div(
                    style={"display": "flex", "gap": "30px", "flexWrap": "wrap"},
                    children=[
                        # Filtros numéricos
                        html.Div(
                            style={"flex": "1 1 300px"},
                            children=[
                                html.H3(
                                    "Filtros numéricos",
                                    style={
                                        "fontSize": "18px",
                                        "color": "#343a40",
                                        "marginBottom": "8px",
                                    },
                                ),
                                html.Div(
                                    children=[
                                        html.Div(
                                            style={"marginBottom": "8px"},
                                            children=[
                                                html.Label(
                                                    numeric_label(col) + " (mín)",
                                                    style={
                                                        "fontSize": "13px",
                                                        "color": "#495057",
                                                    },
                                                ),
                                                dcc.Input(
                                                    id=f"f-num-min-{col}",
                                                    type="number",
                                                    step="any",
                                                    style={
                                                        "width": "100%",
                                                        "padding": "4px 8px",
                                                        "borderRadius": "6px",
                                                        "border": "1px solid #ced4da",
                                                    },
                                                ),
                                                html.Label(
                                                    numeric_label(col) + " (máx)",
                                                    style={
                                                        "fontSize": "13px",
                                                        "color": "#495057",
                                                        "marginTop": "4px",
                                                    },
                                                ),
                                                dcc.Input(
                                                    id=f"f-num-max-{col}",
                                                    type="number",
                                                    step="any",
                                                    style={
                                                        "width": "100%",
                                                        "padding": "4px 8px",
                                                        "borderRadius": "6px",
                                                        "border": "1px solid #ced4da",
                                                    },
                                                ),
                                            ],
                                        )
                                        for col in FILTER_NUM
                                    ]
                                ),
                            ],
                        ),

                        # Filtros categóricos
                        html.Div(
                            style={"flex": "1 1 300px"},
                            children=[
                                html.H3(
                                    "Filtros categóricos",
                                    style={
                                        "fontSize": "18px",
                                        "color": "#343a40",
                                        "marginBottom": "8px",
                                    },
                                ),
                                html.Div(
                                    children=[
                                        html.Div(
                                            style={"marginBottom": "8px"},
                                            children=[
                                                html.Label(
                                                    col,
                                                    style={
                                                        "fontSize": "13px",
                                                        "color": "#495057",
                                                        "marginBottom": "2px",
                                                    },
                                                ),
                                                dcc.Dropdown(
                                                    id=f"f-cat-{col}",
                                                    options=[
                                                        {"label": v, "value": v}
                                                        for v in filter_cat_options[col]
                                                    ],
                                                    placeholder="(Todos)",
                                                    style={"width": "100%"},
                                                ),
                                            ],
                                        )
                                        for col in FILTER_CAT
                                    ]
                                ),
                            ],
                        ),
                    ],
                ),

                html.Div(
                    style={"marginTop": "10px"},
                    children=[
                        html.Button(
                            "Buscar pacientes",
                            id="btn-filtrar",
                            n_clicks=0,
                            style={
                                "backgroundColor": "#0b5ed7",
                                "color": "white",
                                "border": "none",
                                "padding": "8px 18px",
                                "borderRadius": "8px",
                                "fontSize": "15px",
                                "cursor": "pointer",
                            },
                        ),
                        html.Span(
                            id="txt-num-pacientes",
                            style={
                                "marginLeft": "12px",
                                "fontSize": "13px",
                                "color": "#6c757d",
                            },
                        ),
                    ],
                ),

                html.Hr(style={"marginTop": "20px"}),

                # SELECCIÓN DE PACIENTE + RESULTADO
                html.Div(
                    style={"display": "flex", "gap": "30px", "flexWrap": "wrap"},
                    children=[
                        # Lista y ficha paciente
                        html.Div(
                            style={"flex": "1 1 380px"},
                            children=[
                                html.H3(
                                    "Pacientes encontrados",
                                    style={
                                        "fontSize": "18px",
                                        "color": "#343a40",
                                        "marginBottom": "8px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="paciente-dropdown",
                                    options=[],
                                    placeholder="Seleccione un paciente de la lista filtrada...",
                                    style={"width": "100%"},
                                ),
                                html.Div(
                                    id="paciente-card",
                                    style={
                                        "marginTop": "10px",
                                        "padding": "10px 12px",
                                        "backgroundColor": "#f8f9fa",
                                        "borderRadius": "8px",
                                        "border": "1px solid #dee2e6",
                                        "fontSize": "13px",
                                        "color": "#495057",
                                    },
                                ),
                                html.Button(
                                    "Calcular riesgo para paciente seleccionado",
                                    id="btn-predict",
                                    n_clicks=0,
                                    style={
                                        "marginTop": "12px",
                                        "backgroundColor": "#0b5ed7",
                                        "color": "white",
                                        "border": "none",
                                        "padding": "8px 18px",
                                        "borderRadius": "8px",
                                        "fontSize": "15px",
                                        "cursor": "pointer",
                                    },
                                ),
                            ],
                        ),

                        # Predicción vs realidad
                        html.Div(
                            style={"flex": "1 1 380px"},
                            children=[
                                html.H3(
                                    "Resultado del modelo vs realidad",
                                    style={
                                        "fontSize": "18px",
                                        "color": "#343a40",
                                        "marginBottom": "8px",
                                    },
                                ),
                                # tarjeta predicción
                                html.Div(
                                    style={
                                        "padding": "10px 12px",
                                        "backgroundColor": "#f8f9fa",
                                        "borderRadius": "8px",
                                        "border": "1px solid #dee2e6",
                                        "marginBottom": "10px",
                                    },
                                    children=[
                                        html.H4(
                                            "Predicción del modelo",
                                            style={
                                                "margin": "0 0 6px 0",
                                                "fontSize": "15px",
                                                "color": "#343a40",
                                            },
                                        ),
                                        html.Div(
                                            id="output-prob",
                                            style={
                                                "fontSize": "17px",
                                                "fontWeight": "600",
                                                "color": "#0b5ed7",
                                                "marginBottom": "6px",
                                            },
                                        ),
                                        html.Div(
                                            id="risk-bar",
                                            style={"marginBottom": "8px"},
                                        ),
                                        html.Div(
                                            id="output-texto",
                                            style={
                                                "fontSize": "13px",
                                                "color": "#495057",
                                            },
                                        ),
                                    ],
                                ),
                                # tarjeta resultado real
                                html.Div(
                                    style={
                                        "padding": "10px 12px",
                                        "backgroundColor": "#f8f9fa",
                                        "borderRadius": "8px",
                                        "border": "1px solid #dee2e6",
                                        "marginBottom": "10px",
                                    },
                                    children=[
                                        html.H4(
                                            "Resultado real",
                                            style={
                                                "margin": "0 0 6px 0",
                                                "fontSize": "15px",
                                                "color": "#343a40",
                                            },
                                        ),
                                        html.Div(
                                            id="output-real",
                                            style={
                                                "fontSize": "14px",
                                                "color": "#343a40",
                                                "fontWeight": "600",
                                            },
                                        ),
                                    ],
                                ),
                                html.Div(
                                    id="comentario-caso",
                                    style={
                                        "fontSize": "13px",
                                        "color": "#6c757d",
                                        "marginTop": "4px",
                                    },
                                ),
                                html.P(
                                    "⚠️ Esta herramienta es de apoyo a la decisión clínica y aquí se emplea para explorar el rendimiento del modelo sobre pacientes reales. No sustituye el juicio del especialista.",
                                    style={
                                        "fontSize": "11px",
                                        "color": "#adb5bd",
                                        "marginTop": "12px",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),

                html.Hr(style={"marginTop": "20px"}),

                # GRAFICOS: PERFIL + SIMILARES
                html.Div(
                    style={"display": "flex", "gap": "30px", "flexWrap": "wrap"},
                    children=[
                        html.Div(
                            style={"flex": "1 1 380px"},
                            children=[
                                dcc.Graph(id="graph-perfil"),
                            ],
                        ),
                        html.Div(
                            style={"flex": "1 1 380px"},
                            children=[
                                dcc.Graph(id="graph-similares"),
                            ],
                        ),
                    ],
                ),

                html.Hr(style={"marginTop": "20px"}),

                # CALIBRACIÓN + INFO DATASET
                html.Div(
                    style={"display": "flex", "gap": "30px", "flexWrap": "wrap"},
                    children=[
                        html.Div(
                            style={"flex": "1 1 480px"},
                            children=[
                                dcc.Graph(
                                    id="graph-calibracion",
                                    figure=fig_calib,
                                ),
                            ],
                        ),
                        html.Div(
                            style={"flex": "1 1 260px"},
                            children=[
                                html.H4(
                                    "Información del dataset",
                                    style={
                                        "fontSize": "16px",
                                        "color": "#343a40",
                                        "marginBottom": "8px",
                                    },
                                ),
                                html.Div(
                                    dataset_info_text,
                                    id="dataset-info",
                                    style={
                                        "fontSize": "13px",
                                        "color": "#495057",
                                        "marginBottom": "10px",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
            ],
        )
    ],
)

# ============================================================
# 8. CALLBACKS
# ============================================================

# 8.0. Actualizar opciones de tratamiento_actual según tipo_tumor
@app.callback(
    [Output("f-cat-tratamiento_actual", "options"),
     Output("f-cat-tratamiento_actual", "value")],
    Input("f-cat-tipo_tumor", "value"),
    State("f-cat-tratamiento_actual", "value"),
)
def actualizar_tratamientos_por_tumor(tipo_tumor_sel, tratamiento_sel):
    if tipo_tumor_sel in [None, ""]:
        opts = [
            {"label": v, "value": v}
            for v in sorted(df_all["tratamiento_actual"].dropna().astype(str).unique())
        ]
        if tratamiento_sel in [o["value"] for o in opts]:
            return opts, tratamiento_sel
        else:
            return opts, None

    dff = df_all[df_all["tipo_tumor"].astype(str) == str(tipo_tumor_sel)]
    vals = sorted(dff["tratamiento_actual"].dropna().astype(str).unique())
    opts = [{"label": v, "value": v} for v in vals]

    if tratamiento_sel in vals:
        return opts, tratamiento_sel
    else:
        return opts, None

# 8.1. Filtrar pacientes
@app.callback(
    [Output("paciente-dropdown", "options"),
     Output("paciente-dropdown", "value"),
     Output("txt-num-pacientes", "children")],
    Input("btn-filtrar", "n_clicks"),
    [State(f"f-num-min-{col}", "value") for col in FILTER_NUM] +
    [State(f"f-num-max-{col}", "value") for col in FILTER_NUM] +
    [State(f"f-cat-{col}", "value") for col in FILTER_CAT],
)
def filtrar_pacientes(n_clicks, *values):
    num_mins = values[:len(FILTER_NUM)]
    num_maxs = values[len(FILTER_NUM):2*len(FILTER_NUM)]
    cat_vals = values[2*len(FILTER_NUM):]

    dff = df_all.copy()

    for col, vmin, vmax in zip(FILTER_NUM, num_mins, num_maxs):
        if vmin is not None:
            dff = dff[dff[col] >= vmin]
        if vmax is not None:
            dff = dff[dff[col] <= vmax]

    for col, val in zip(FILTER_CAT, cat_vals):
        if val not in [None, ""]:
            dff = dff[dff[col].astype(str) == str(val)]

    dff = dff.head(200)

    options = []
    for idx, row in dff.iterrows():
        vive_txt = "VIVIÓ" if row["vive"] == 1 else "FALLECIÓ"
        label = f"#{idx} · edad {row['edad']:.0f} · {row['tipo_tumor']} · {row['tratamiento_actual']} · {vive_txt}"
        options.append({"label": label, "value": int(idx)})

    num_pac = len(dff)
    txt = f"Pacientes encontrados: {num_pac}"
    value = options[0]["value"] if options else None

    return options, value, txt

# 8.2. Ficha del paciente (card)
@app.callback(
    Output("paciente-card", "children"),
    Input("paciente-dropdown", "value"),
)
def mostrar_ficha_paciente(idx):
    if idx is None:
        return "Seleccione un paciente para ver su ficha clínica básica."
    row = df_all.loc[idx]
    vive_txt = "VIVIÓ" if row["vive"] == 1 else "FALLECIÓ"
    return [
        html.Div(f"Paciente #{idx}", style={"fontWeight": "600", "marginBottom": "4px"}),
        html.Div(f"Edad: {row['edad']:.0f} años"),
        html.Div(f"Tipo de tumor: {row['tipo_tumor']}"),
        html.Div(f"Tratamiento actual: {row['tratamiento_actual']}"),
        html.Div(f"Tipo de hospital: {row['hospital_tipo']}"),
        html.Div(f"Resultado real: {vive_txt} (vive={int(row['vive'])})"),
    ]

# 8.3. Riesgo del modelo + gráficos dinámicos
@app.callback(
    [Output("output-prob", "children"),
     Output("output-texto", "children"),
     Output("risk-bar", "children"),
     Output("output-real", "children"),
     Output("comentario-caso", "children"),
     Output("graph-similares", "figure"),
     Output("graph-perfil", "figure")],
    Input("btn-predict", "n_clicks"),
    State("paciente-dropdown", "value"),
)
def calcular_riesgo_paciente(n_clicks, idx):
    if n_clicks == 0 or idx is None:
        return "", "", "", "", "", go.Figure(), go.Figure()

    row = df_all.loc[idx]
    prob = predict_from_row(row)
    texto = texto_recomendacion(prob)
    barra = barra_riesgo(prob)

    vive_real = row["vive"]
    if vive_real == 1:
        real_txt = "Resultado real: EL PACIENTE VIVIÓ (vive = 1)"
    else:
        real_txt = "Resultado real: EL PACIENTE FALLECIÓ (vive = 0)"

    comentario = comentario_caso(prob, vive_real)
    fig_similares = grafico_similares(row)
    fig_perfil = grafico_perfil(row)

    return (
        f"Probabilidad estimada de supervivencia (clase 1): {prob*100:.1f}%",
        texto,
        barra,
        real_txt,
        comentario,
        fig_similares,
        fig_perfil,
    )

# ============================================================
# 9. RUN
# ============================================================
if __name__ == "__main__":
    app.run(debug=True)
